//
// Created by Oleh SAK on 2019-05-16.
//

#ifndef DOOM_NUKEM_SYSTEM_H
#define DOOM_NUKEM_SYSTEM_H


#include <math.h>
#include <SDL2/SDL.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>

/* Define window size */
#define W2 1280 // width of screen
#define H 800  // height of screen
#define W 1280  // width of _game_ screen (in SplitScreen mode, map is drawn in the remaining space)
/* Define camera height from floor and distance to ceiling */
#define EyeHeight  6
#define DuckHeight 2.5
#define HeadMargin 1
#define KneeHeight 2 /* Maximum walkable obstacle height */
/* Define factors that affect the field of vision (never >= 180 degrees though) */
#define hfov (1.0 * 0.73f*H/W)
#define vfov (1.0 * .2f)

//#define TextureMapping
//#define DepthShading
//#define LightMapping
//#define VisibilityTracking
//#define SplitScreen

// Utility functions. Because C doesn't have templates,
// we use the slightly less safe preprocessor macros to
// implement these functions that work with multiple types.
#define min(a,b) (((a) < (b)) ? (a) : (b)) // min: Choose smaller of two values.
#define max(a,b) (((a) > (b)) ? (a) : (b)) // max: Choose bigger of two values.
#define abs(a) ((a) < 0 ? -(a) : (a))
#define clamp(a, mi,ma) min(max(a,mi),ma)  // clamp: Clamp value into set range.
#define sign(v) (((v) > 0) - ((v) < 0))    // sign: Return the sign of a value (-1, 0 or 1)
#define vxs(x0,y0, x1,y1) ((x0)*(y1) - (x1)*(y0)) // vxs: Vector cross product
// Overlap:  Determine whether the two number ranges overlap.
#define Overlap(a0,a1,b0,b1) (min(a0,a1) <= max(b0,b1) && min(b0,b1) <= max(a0,a1))
// IntersectBox: Determine whether two 2D-boxes intersect.
#define IntersectBox(x0,y0, x1,y1, x2,y2, x3,y3) (Overlap(x0,x1,x2,x3) && Overlap(y0,y1,y2,y3))
// PointSide: Determine which side of a line the point is on. Return value: -1, 0 or 1.
#define PointSide(px,py, x0,y0, x1,y1) sign(vxs((x1)-(x0), (y1)-(y0), (px)-(x0), (py)-(y0)))
// Intersect: Calculate the point of intersection between two lines.
#define Intersect(x1,y1, x2,y2, x3,y3, x4,y4) ((t_xy) { \
    vxs(vxs(x1,y1, x2,y2), (x1)-(x2), vxs(x3,y3, x4,y4), (x3)-(x4)) / vxs((x1)-(x2), (y1)-(y2), (x3)-(x4), (y3)-(y4)), \
    vxs(vxs(x1,y1, x2,y2), (y1)-(y2), vxs(x3,y3, x4,y4), (y3)-(y4)) / vxs((x1)-(x2), (y1)-(y2), (x3)-(x4), (y3)-(y4)) })

// Some hard-coded limits.
#define MaxVertices 100 // maximum number of vertices in a map
#define MaxEdges 100    // maximum number of edges in a sector
#define MaxQueue 32     // maximum number of pending portal renders

#ifdef TextureMapping
typedef int Texture[1024][1024];
struct TextureSet { Texture texture, normalmap, lightmap, lightmap_diffuseonly; };
#endif


// FIX MEEeeeeee//

//
//typedef struct  s_start
//{
//    float x,y,angle,number, numbers[MaxEdges];
//    int n, m;
//}               t_start;





/* Sectors: Floor and ceiling height; list of wall vertexes and neighbors */

typedef struct  s_xy
{
    float x;
    float y;
}               t_xy;

static struct       sector
{
    float           floor;
    float           ceil;
    t_xy            *vertex;
//    struct t_xy { float x, y; } *vertex;
    unsigned short  npoints;            /* How many vertexes there are */
    signed char     *neighbors;            /* Each pair of vertexes may have a corresponding neighboring sector */
#ifdef VisibilityTracking
    int             visible;
#endif

#ifdef TextureMapping
    struct TextureSet *floortexture, *ceiltexture, *uppertextures, *lowertextures;
#endif
}       *sectors = NULL;

typedef struct      s_sect
{
    float           floor;
    float           ceil;
    t_xy            *vertex;
//    struct t_xy { float x, y; } *vertex;
    unsigned short  npoints;            /* How many vertexes there are */
    signed char     *neighbors;            /* Each pair of vertexes may have a corresponding neighboring sector */
#ifdef VisibilityTracking
    int             visible;
#endif

#ifdef TextureMapping
    struct TextureSet *floortexture, *ceiltexture, *uppertextures, *lowertextures;
#endif
}                   *t_sect;

//static unsigned NumSectors = 0;

#ifdef VisibilityTracking
#define MaxVisibleSectors 256
 struct xy VisibleFloorBegins[MaxVisibleSectors][W], VisibleFloorEnds[MaxVisibleSectors][W];
 char VisibleFloors[MaxVisibleSectors][W];
 struct xy VisibleCeilBegins[MaxVisibleSectors][W], VisibleCeilEnds[MaxVisibleSectors][W];
 char VisibleCeils[MaxVisibleSectors][W];
 unsigned NumVisibleSectors=0;
#endif

//struct item {
//    short sectorno,sx1,sx2;
//} queue[MaxQueue], *head=queue, *tail=queue;

/* Player: location */
typedef struct  s_xyz {
    float x;
    float y;
    float z;
}               t_xyz;

typedef struct  s_velocity {
    float x;
    float y;
    float z;
}               t_velocity;

typedef struct  s_player
{
    t_xyz       *where;      /* Current position */
    t_velocity  *velocity;   /* Current motion vector */

    /* Looking towards (and sin() and cos() thereof) */
    float       angle;
    float       anglesin;
    float       anglecos;
    float       yaw;

    /* Which sector the player is currently in */
    unsigned char sector;

    int         pos[4];
    int         ground;
    int         falling;
    int         moving;
    int         ducking;
    int         map;
    struct       sector;

}               t_player;

#ifdef LightMapping
static struct light
{
    struct t_xyz where, light;
    unsigned char sector;
}* lights = NULL;
static unsigned NumLights = 0;
#endif

void init_pl(t_player *p);
int done(int *NumSectors, t_sect *sectors);
void key_event(SDL_Event ev, t_player *player, int *num_sect, t_sect *sector);
//void UnloadData(void);

void MovePlayer(t_player *player);

void SaveFrame1(SDL_Surface* surface);

void SaveFrame2(SDL_Surface* surface);

void    LoadData(int *numsect);

void mous_aim(t_player *player, float *yaw);

#endif //DOOM_NUKEM_SYSTEM_H

#ifndef DOOM_NUCKEM_PLAYER_H
# define DOOM_NUCKEM_PLAYER_H

# include "ft_math.h"

/* Player: location
** where - Current position
** velocity - Current motion vector
** angle, anglesin,
** 			anglecos, yaw - Looking towards (and sin() and cos() thereof)
** sector - Which sector the player is currently in
**
**
**
**
**
*/

//typedef struct	s_player
//{
//	t_vector	pos;
//	t_vector	velocity;
//	float		angle;
//	float		anglesin;
//	float		anglecos;
//	float		yaw;
//	unsigned	sector;
//}				t_player;

typedef
#endif

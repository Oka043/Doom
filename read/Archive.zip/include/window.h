
#ifndef DOOM_NUKEM_WINDOW_H
# define DOOM_NUKEM_WINDOW_H

/* Define window size */
# define W 1024
# define H 800


typedef struct	s_window
{
	float 		width;
	float 		height;
}				t_window;

#endif

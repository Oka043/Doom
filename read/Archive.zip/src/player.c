//#include "system.h"

//void MovePlayer(float dx, float dy, t_player *player)
//{
//    float px = player->where->x,    py = player->where->y;
//    /* Check if this movement crosses one of this sector's edges
//     * that have a neighboring sector on the other side.
//     * Because the edge vertices of each sector are defined in
//     * clockwise order, PointSide will always return -1 for a point
//     * that is outside the sector and 0 or 1 for a point that is inside.
//     */
//    const struct sector* const sect = &sectors[player->sector];
//    for(int s = 0; s < sect->npoints; ++s)
//        if(sect->neighbors[s] >= 0
//           && IntersectBox(px,py, px+dx,py+dy,
//                           sect->vertex[s+0].x, sect->vertex[s+0].y,
//                           sect->vertex[s+1].x, sect->vertex[s+1].y)
//           && PointSide(px+dx, py+dy,
//                        sect->vertex[s+0].x, sect->vertex[s+0].y,
//                        sect->vertex[s+1].x, sect->vertex[s+1].y) < 0)
//        {
//            player->sector = sect->neighbors[s];
//            printf("Player is now in sector %d\n", player->sector);
//            break;
//        }
//
//    player->where->x += dx;
//    player->where->y += dy;
//    player->anglesin = sinf(player->angle);
//    player->anglecos = cosf(player->angle);
//}
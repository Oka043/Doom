#include "system.h"


void key_event(SDL_Event ev, t_player *player, int *NumSectors, t_sect *sect)
{
    while(SDL_PollEvent(&ev))
    {
        switch(ev.type)
        {
            case SDL_KEYDOWN:
            case SDL_KEYUP:
                switch(ev.key.keysym.sym)
                {
                    case 'w': player->pos[0] = ev.type==SDL_KEYDOWN; break;
                    case 's': player->pos[1] = ev.type==SDL_KEYDOWN; break;
                    case 'a': player->pos[2] = ev.type==SDL_KEYDOWN; break;
                    case 'd': player->pos[3] = ev.type==SDL_KEYDOWN; break;
                    case SDLK_ESCAPE : done(NumSectors, sect);
                    case SDLK_SPACE : /* jump */
                        if(player->ground)
                        {
                            player->velocity->z += 0.5;
                            player->falling = 1;
                        }
                        break;
                    case SDLK_LCTRL: /* duck */
                    case SDLK_RCTRL: player->ducking = ev.type==SDL_KEYDOWN;
                        player->falling=1;
                        break;
                    case SDLK_TAB: player->map = ev.type==SDL_KEYDOWN; break;
                    default: break;
                }
                break;
            case SDL_QUIT: done(NumSectors, sect);
        }
    }
}

//void       UnloadData(unsigned *NumSectors, struct sector *sectors)
//{
//    for(unsigned a = 0; a < *NumSectors; ++a)
//        free(sectors[a].vertex), free(sectors[a].neighbors);
//    free(sectors);
//    sectors = NULL;
//    *NumSectors = 0;
//}

int done(int *NumSectors, t_sect *sectors)
{
    //    UnloadData();
    for(unsigned a=0; a < *NumSectors; ++a)
        free(sectors[a]->vertex), free(sectors[a]->neighbors);
    free(sectors);
    *sectors    = NULL;

    SDL_Quit();
    return 0;
}

void mous_aim(t_player *player, float *yaw)
{
    int x,y;

    SDL_GetRelativeMouseState(&x,&y);
    player->angle += x * 0.03f;
    *yaw          = clamp(*yaw + y*0.05f, -5, 5);
    player->yaw   = *yaw - player->velocity->z*0.5f;
    MovePlayer(player);
}
#include "system.h"

void init_pl(t_player *player)
{
    player->where->x = 4;
    player->where->y = 8;
    player->where->z = 6;

    player->pos[0] = 0;
    player->pos[1] = 0;
    player->pos[2] = 0;
    player->pos[3] = 0;
    player->ground = 0;
    player->falling = 1;
    player->moving = 0;
    player->ducking = 0;
    player->map = 0;
}

#include "camera.h"

void			clip_camera(t_camera *camera, t_vector *start, t_vector *end)
{

}
#include "system.h"


//void vertex()
//{
//    for(sscanf(ptr += n, "%f%n", &y, &n); sscanf(ptr += n, "%f%n", &x, &n) == 1; )
//    {
//        if(vertexptr >= vertex+MaxVertices)
//            fprintf(stderr, "ERROR: Too many vertices, limit is %u\n", MaxVertices); exit(2);
//        *vertexptr++ = (t_xy) { x, y };
//    }
//}


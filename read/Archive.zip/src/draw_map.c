//#include "system.h"

void DrawMap(t_player *player, SDL_Surface* surface, int *numsect)
{
    static unsigned process = ~0u; ++process;

    int NumSectors;

    NumSectors = *numsect;

    // Render the 2D map on screen
    SDL_LockSurface(surface);
#ifdef SplitScreen
    for(unsigned y=0; y<H; ++y)
        memset( (char*)surface->pixels + (y*W2 + W)*4, 0, (W2-W)*4);
#else
    for(unsigned y=0; y<H; ++y)
        memset( (char*)surface->pixels + (y*W2)*4, 0, (W)*4);
#endif

#ifdef SplitScreen
    float square = min(W/20.f/0.8, H/29.f), X = (W2-W)/20.f/*square*0.8*/, Y = square, X0 = W+X*1.f/*(W-18*square*0.8)/2*/, Y0 = (H-28*square)/2;
#else
    float square = min(W/20.f/0.8, H/29.f), X = square*0.8, Y = square, X0 = (W-18*square*0.8)/2, Y0 = (H-28*square)/2;
#endif
    for(float x=0; x<=18; ++x)
        line(X0+x*X, Y0+0*Y, X0+ x*X, Y0+28*Y, 0x002200, surface);
    for(float y=0; y<=28; ++y)
        line(X0+0*X, Y0+y*Y, X0+18*X, Y0+ y*Y, 0x002200, surface);

#ifdef VisibilityTracking
    for(unsigned c=0; c<NumSectors; ++c) if(sectors[c].visible) fillpolygon(&sectors[c], 0x220000, surface);
#endif
    fillpolygon(&sectors[player->sector], 0x440000, surface);

#ifdef VisibilityTracking
    for(unsigned c=0; c<NumVisibleSectors; ++c)
    {
        /*struct xy vert[W*2];
        struct sector temp_sector = {0,0,vert,0,0,0};
        for(unsigned x=0; x<W; ++x)  if(VisibleFloors[c][x]) vert[temp_sector.npoints++] = VisibleFloorBegins[c][x];
        for(unsigned x=W; x-- > 0; ) if(VisibleFloors[c][x]) vert[temp_sector.npoints++] = VisibleFloorEnds[c][x];
        fillpolygon(&temp_sector, 0x222200);
        temp_sector.npoints = 0;
        for(unsigned x=0; x<W; ++x)  if(VisibleCeils[c][x]) vert[temp_sector.npoints++] = VisibleCeilBegins[c][x];
        for(unsigned x=W; x-- > 0; ) if(VisibleCeils[c][x]) vert[temp_sector.npoints++] = VisibleCeilEnds[c][x];
        fillpolygon(&temp_sector, 0x220022);*/

        for(unsigned x=0; x<W; ++x)
        {
            if(VisibleFloors[c][x])
                line(clamp(X0 + VisibleFloorBegins[c][x].y*X, 0,W2-1), clamp(Y0 + (28-VisibleFloorBegins[c][x].x)*Y, 0,H-1),
                     clamp(X0 + VisibleFloorEnds[c][x].y*X, 0,W2-1), clamp(Y0 + (28-VisibleFloorEnds[c][x].x)*Y, 0,H-1),
                     0x222200);
            if(VisibleCeils[c][x])
                line(clamp(X0 + VisibleCeilBegins[c][x].y*X, 0,W2-1), clamp(Y0 + (28-VisibleCeilBegins[c][x].x)*Y, 0,H-1),
                     clamp(X0 + VisibleCeilEnds[c][x].y*X, 0,W2-1), clamp(Y0 + (28-VisibleCeilEnds[c][x].x)*Y, 0,H-1),
                     0x28003A);
        }
    }
    /*for(unsigned n=0; n<NumVisibleFloors; ++n)
    {
        printf("%g,%g - %g,%g\n", VisibleFloorBegins[n].x, VisibleFloorBegins[n].y,
                                  VisibleFloorEnds[n].x, VisibleFloorEnds[n].y );
        line( X0+VisibleFloorBegins[n].x*X, Y0+VisibleFloorBegins[n].y*Y,
              X0+VisibleFloorEnds[n].x*X,   Y0+VisibleFloorEnds[n].y*Y,
              n*0x010101
              //0x550055
             );
    }*/
#endif

    for(unsigned c=0; c<NumSectors; ++c)
    {
        unsigned a = c;
        if(a == player->sector && player->sector != (NumSectors-1))
            a = NumSectors-1;
        else if(a == NumSectors-1)
            a = player->sector;

        const struct sector* const sect = &sectors[a];
        const t_xy* const vert = sect->vertex;
        for(unsigned b = 0; b < sect->npoints; ++b)
        {
            float x0 = 28-vert[b].x, x1 = 28-vert[b+1].x;
            unsigned vertcolor = a==player->sector ? 0x55FF55
                                 #ifdef VisibilityTracing
                                 : sect->visible ? 0x55FF55
                                 #endif
                                                   : 0x00AA00;

            line( X0+vert[b].y*X, Y0+x0*Y,
                  X0+vert[b+1].y*X, Y0+x1*Y,
                  (a == player->sector)
                  ? (sect->neighbors[b] >= 0 ? 0xFF5533 : 0xFFFFFF)
                  #ifdef VisibilityTracing
                  : (sect->visible)
                 ?   (sect->neighbors[b] >= 0 ? 0xFF3333 : 0xAAAAAA)
                  #endif
                  : (sect->neighbors[b] >= 0 ? 0x880000 : 0x6A6A6A), surface
            );

            line( X0+vert[b].y*X-2, Y0+x0*Y-2, X0+vert[b].y*X+2, Y0+x0*Y-2, vertcolor, surface);
            line( X0+vert[b].y*X-2, Y0+x0*Y-2, X0+vert[b].y*X-2, Y0+x0*Y+2, vertcolor, surface);
            line( X0+vert[b].y*X+2, Y0+x0*Y-2, X0+vert[b].y*X+2, Y0+x0*Y+2, vertcolor, surface);
            line( X0+vert[b].y*X-2, Y0+x0*Y+2, X0+vert[b].y*X+2, Y0+x0*Y+2, vertcolor, surface);
        }
    }

    float c = player->anglesin, s = -player->anglecos;
    float px = player->where->y,    tx = px+c*0.8f, qx0 = px+s*0.2f, qx1=px-s*0.2f;
    float py = 28-player->where->x, ty = py+s*0.8f, qy0 = py-c*0.2f, qy1=py+c*0.2f;
    px = clamp(px,-.4f,18.4f); tx = clamp(tx,-.4f,18.4f); qx0 = clamp(qx0,-.4f,18.4f); qx1 = clamp(qx1,-.4f,18.4f);
    py = clamp(py,-.4f,28.4f); ty = clamp(ty,-.4f,28.4f); qy0 = clamp(qy0,-.4f,28.4f); qy1 = clamp(qy1,-.4f,28.4f);

    line(X0 + px*X, Y0 + py*Y,  X0 + tx*X, Y0 + ty*Y, 0x5555FF, surface);
    line(X0 +qx0*X, Y0 +qy0*Y,  X0 +qx1*X, Y0 +qy1*Y, 0x5555FF, surface);

    BloomPostprocess(surface);

    SDL_UnlockSurface(surface);
    SaveFrame1(surface);

    //static unsigned skip=0;
    //if(++skip >= 1) { skip=0; SDL_Flip(surface); }
    *numsect = NumSectors;
}